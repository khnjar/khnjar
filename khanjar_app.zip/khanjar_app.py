import streamlit as st
import random
import time

class Sensor:
    def __init__(self):
        self.heart_rate = 70
        self.oxygen_level = 98
        self.temperature = 36.5
        self.air_quality = 25
        self.seismic_activity = 0.5
        self.sleep_hours = 7
        self.stress_index = 2

    def read_data(self):
        self.heart_rate += random.uniform(-5, 5)
        self.oxygen_level += random.uniform(-1, 1)
        self.temperature += random.uniform(-0.3, 0.3)
        self.air_quality += random.uniform(-3, 3)
        self.seismic_activity += random.uniform(-0.1, 0.1)
        self.sleep_hours += random.uniform(-0.5, 0.5)
        self.stress_index += random.uniform(-0.5, 0.5)

        return {
            'heart_rate': round(self.heart_rate, 2),
            'oxygen_level': round(self.oxygen_level, 2),
            'temperature': round(self.temperature, 2),
            'air_quality': round(self.air_quality, 2),
            'seismic_activity': round(self.seismic_activity, 2),
            'sleep_hours': round(self.sleep_hours, 2),
            'stress_index': round(self.stress_index, 2)
        }

class RiskAnalyzer:
    def __init__(self):
        self.hr_threshold = 100
        self.oxygen_threshold = 93
        self.temp_threshold = 38
        self.air_quality_threshold = 100
        self.seismic_threshold = 4.5
        self.sleep_threshold = 4
        self.stress_threshold = 7

    def analyze(self, data):
        risk_score = 0
        if data['heart_rate'] > self.hr_threshold:
            risk_score += 1
        if data['oxygen_level'] < self.oxygen_threshold:
            risk_score += 1
        if data['temperature'] > self.temp_threshold:
            risk_score += 1
        if data['air_quality'] > self.air_quality_threshold:
            risk_score += 1
        if data['seismic_activity'] > self.seismic_threshold:
            risk_score += 1
        if data['sleep_hours'] < self.sleep_threshold:
            risk_score += 1
        if data['stress_index'] > self.stress_threshold:
            risk_score += 1

        if risk_score <= 1:
            return "آمن", "✅"
        elif risk_score <= 3:
            return "احتمال خطر متوسط", "⚠️"
        elif risk_score <= 5:
            return "خطر مرتفع", "❗"
        else:
            return "خطر حرج - تدخل فوري", "❌"

sensor = Sensor()
analyzer = RiskAnalyzer()

st.title("لوحة مراقبة خنجر")
st.markdown("### مراقبة البيانات الحيوية والبيئية والسلوكية")

if st.button("تحديث القراءة"):
    data = sensor.read_data()
    status, icon = analyzer.analyze(data)

    st.metric("معدل ضربات القلب", f"{data['heart_rate']} bpm")
    st.metric("نسبة الأكسجين", f"{data['oxygen_level']} %")
    st.metric("درجة الحرارة", f"{data['temperature']} °C")
    st.metric("جودة الهواء (AQI)", f"{data['air_quality']}")
    st.metric("النشاط الزلزالي", f"{data['seismic_activity']}")
    st.metric("عدد ساعات النوم", f"{data['sleep_hours']} ساعة")
    st.metric("مؤشر التوتر", f"{data['stress_index']}")

    st.markdown(f"## التقييم العام: {icon} {status}")
